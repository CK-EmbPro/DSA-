#include<iostream>
using namespace std;

int main(){
    float x = 5/2;
    cout<<x<<endl;
    return 0;
}